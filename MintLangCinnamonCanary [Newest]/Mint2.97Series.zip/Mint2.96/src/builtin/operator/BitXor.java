package builtin.operator;

import builtin.BuiltinSub;
import java.math.BigInteger;
import mint.Constants;
import mint.Heap;
import mint.MintException;
import mint.Pointer;
import mint.PointerTools;
import mint.SmartList;

/**
 *
 * @author Oliver Chu
 */
public class BitXor extends BuiltinSub {

    @Override
    public Pointer apply(SmartList<Pointer> args) throws MintException {
        Pointer arg0 = args.get(0);
        Pointer arg1 = args.get(1);
        if (arg0.type == Constants.BIG_INT_TYPE &&
            arg1.type == Constants.BIG_INT_TYPE) {
            BigInteger op0 = PointerTools.dereferenceBigInt(arg0);
            BigInteger op1 = PointerTools.dereferenceBigInt(arg1);
            return Heap.allocateBigInt(op0.xor(op1));
        }
        Integer operand0 = PointerTools.dereferenceInt(arg0);
        Integer operand1 = PointerTools.dereferenceInt(arg1);
        if (operand0 == null || operand1 == null) {
            throw new MintException("Bitwise xor can only be applied to " + 
                                    "integers.");
        }
        return Heap.allocateInt(operand0 ^ operand1);
    }
    
}
