package builtin.operator;

import builtin.BuiltinSub;
import java.math.BigDecimal;
import java.math.BigInteger;
import mint.Constants;
import mint.Heap;
import mint.MintException;
import mint.Pointer;
import mint.PointerTools;
import mint.SmartList;

/**
 *
 * @author Oliver Chu
 */
public class Minus extends BuiltinSub {

    @Override
    public Pointer apply(SmartList<Pointer> args) throws MintException {
        Pointer arg0 = args.get(0);
        Pointer arg1 = args.get(1);
        if (arg0.type == Constants.BIG_INT_TYPE &&
            arg1.type == Constants.BIG_INT_TYPE) {
            BigInteger bi0 = PointerTools.dereferenceBigInt(arg0);
            BigInteger bi1 = PointerTools.dereferenceBigInt(arg1);
            return Heap.allocateBigInt(bi0.subtract(bi1));
        } else if (arg0.type == Constants.PRECISE_REAL_TYPE &&
                   arg1.type == Constants.PRECISE_REAL_TYPE) {
            BigDecimal bd0 = PointerTools.dereferencePreciseReal(arg0);
            BigDecimal bd1 = PointerTools.dereferencePreciseReal(arg1);
            return Heap.allocatePreciseReal(bd0.subtract(bd1));
        }
        if (arg0.type == Constants.INT_TYPE && arg1.type == Constants.INT_TYPE)
        {
            int operand0 = PointerTools.dereferenceInt(arg0);
            int operand1 = PointerTools.dereferenceInt(arg1);
            return Heap.allocateInt(operand0 - operand1);
        } else {
            Double operand0 = PointerTools.dereferenceReal(arg0);
            Double operand1 = PointerTools.dereferenceReal(arg1);
            if (arg0 == null || arg1 == null) {
                throw new MintException("Minus can only be applied to " + 
                                        "integers or reals.");
            }
            return Heap.allocateReal(operand0 - operand1);
        }
    }
    
}
