package builtin.math;

import builtin.BuiltinSub;
/* import mint.Constants;
import mint.Environment;
import mint.Interpreter; */
import mint.MintException;
import mint.Pointer;
// import mint.PointerTools;
import mint.SmartList;
// import mint.Subprogram;

/**
 * @author Oliver Chu
 */
public class TextGraph extends BuiltinSub {
    @Override
    public Pointer apply(SmartList<Pointer> args) throws MintException {
        /* Subprogram s = PointerTools.dereferenceSub(args.get(0));
        Double startX = PointerTools.dereferenceReal(args.get(1));
        Double stepX = PointerTools.dereferenceReal(args.get(2));
        Double maximum = Double.NEGATIVE_INFINITY;
        Double minimum = Double.POSITIVE_INFINITY;
        final int HEIGHT_GRAPH = 32;
        final int WIDTH_GRAPH = 64;
        return Constants.MINT_NULL;
        // KEEP DOING THIS FOR ALL ARGS...
        s.execute(new Environment(), new SmartList<String>(), new SmartList<Pointer>(), new Interpreter()); */
        return null;
    }
}
